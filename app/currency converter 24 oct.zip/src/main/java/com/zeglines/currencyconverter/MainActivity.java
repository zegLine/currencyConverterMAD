package com.zeglines.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Spinner from_value_spinner;
    Spinner to_value_spinner;
    EditText amount_text;

    ExchangeRateDatabase forexDb = new ExchangeRateDatabase();

    TextView result_text_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] currencies = forexDb.getCurrencies();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                        R.layout.spinner_element_view,
                        R.id.spinner_text_element,
                        currencies
        );

        from_value_spinner = findViewById(R.id.from_value_spinner);
        to_value_spinner = findViewById(R.id.to_value_spinner);

        amount_text = findViewById(R.id.edit_text_value);
        result_text_view = findViewById(R.id.result_text_view);

        from_value_spinner.setAdapter(adapter);
        to_value_spinner.setAdapter(adapter);
    }

    public void calculateConversion(View v) {
        Log.i("Converter", "Calculate Button Clicked!");

        String from_cur = (String) from_value_spinner.getSelectedItem();
        String to_cur = (String) to_value_spinner.getSelectedItem();
        Log.i("Converter", "From " + from_cur);
        Log.i("Converter", "To " + to_cur);

        double value = Double.parseDouble(amount_text.getText().toString());
        Log.i("Converter", "Value is " + value);

        double result = forexDb.convert(value, from_cur, to_cur);
        Log.i("Converter", "Result is " + result);

        result_text_view.setText(String.valueOf(result));

    }
}