package com.zeglines.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CurrencyListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency_list);

        ExchangeRateDatabase forexDb = new ExchangeRateDatabase();
        String[] currencies = forexDb.getCurrencies();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.spinner_element_view,
                R.id.spinner_text_element,
                currencies
        );

        ListView lv = findViewById(R.id.list_view_currencies);
        lv.setAdapter(adapter);

    }
}